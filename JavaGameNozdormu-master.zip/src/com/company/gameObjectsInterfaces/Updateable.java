package com.company.gameObjectsInterfaces;

public interface Updateable {
    void update();
}
