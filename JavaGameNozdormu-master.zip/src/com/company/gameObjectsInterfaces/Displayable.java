package com.company.gameObjectsInterfaces;

import java.awt.*;

public interface Displayable {
    void display(Graphics g);
}
