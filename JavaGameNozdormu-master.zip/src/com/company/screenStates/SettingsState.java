package com.company.screenStates;

import java.awt.*;

public class SettingsState extends State{

    @Override
    public void update() {

    }

    //TODO: Display controls of the game and the basic idea of the game
    @Override
    public void display(Graphics g) {

    }

}
