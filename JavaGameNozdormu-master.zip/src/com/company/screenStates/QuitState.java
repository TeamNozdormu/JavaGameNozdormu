package com.company.screenStates;

import java.awt.*;

/**
 * Created by stil2_000 on 4.11.2015 �..
 */
public class QuitState extends State {

    @Override
    public void update() {

    }

    @Override
    public void display(Graphics g) {

    }

    //TODO: Display Credits?

}
